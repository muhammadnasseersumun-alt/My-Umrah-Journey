# Rihla: full-build prompt for Lovable

Build "Rihla", a mobile-first multilingual (English, Arabic RTL, Urdu, French, then Malay, Indonesian, Turkish, Bengali, Hindi, Swahili) interactive Umrah and Hajj journey app. Sunni sources only; every ruling, dua and historical note shows a citation and a scholar-review status. A visible notice tells users to confirm rulings with a qualified scholar. No depiction of Prophets or Companions.

## Onboarding
Name, avatar (girl, boy, man, woman), Umrah or Hajj, madhhab (Hanafi, Maliki, Shafi'i, Hanbali), country, travel date. Generates a personalised timeline and countdown.

## Stages (later stages lock until earlier ones are done)
1. Home market (react-three-fiber low-poly street): Ihram House, Bags and Cases, Pilgrim Essentials. Tap a shop to enter.
2. Barakah Wallet: earn credits by reciting Durood, Azkaar, short Surahs or listening to Naat (reciter audio, tap counter or timer, daily streak, badges).
3. Shopkeeper chat and bargaining: AI shopkeeper (Lovable AI edge function) in the user's language. Good manners (greeting, please, thanks) and fair offers lower the price down to a floor; rudeness does not.
4. Packing: suitcase with airline weight limit, forgotten-essentials warnings.
5. Travel: flight search and booking simulator, visa document checklist and status tracker pointing to official channels (Nusuk), pre-flight checklist.
6. Makkah and Madinah rites, one locked step at a time: ihram and niyyah, talbiyah, tawaf (7-circuit counter), prayer at Maqam and Zamzam, sa'i (7-lap Safa/Marwah tracker), halq or taqsir. Hajj mode adds Mina, Arafat, Muzdalifah, Jamarat, qurbani, Tawaf al-Ifadah, Farewell Tawaf. Each step has dua (Arabic, transliteration, meaning), common mistakes, madhhab differences, audio, source, and a quiz.
7. After completion: Makkah and Madinah bazaar (food, dates, Zamzam, attar, clothing, gifts) with the same bargaining, and a landmark explorer (Masjid al-Haram, Masjid an-Nabawi, Jabal al-Nur, Jabal Thawr, Quba, Qiblatayn, Uhud, Baqi) with sourced history and etiquette.

## Extra features
Searchable duas library by situation with favourites and offline cards. Family group mode with shared checklist and per-member progress (needs accounts and sync). AI "ask a question" helper that answers only from the app's sourced content and cites it. Budget planner with currency conversion. Elderly-friendly mode (large text, voice reading). Shareable completion certificate.

## Design
Deep green, gold accents, calm light surface, dark mode. Amiri/Noto Naskh for Arabic. Respectful, uncluttered.

## Tech
React, TypeScript, Tailwind, shadcn/ui, react-three-fiber, i18n, Lovable Cloud (auth, profiles, wallet, progress, groups, content with citations). Row-level security on all user data. Package as Android and iOS apps with Capacitor.
