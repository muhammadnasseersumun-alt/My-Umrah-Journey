# Rihla Android app

Guided Umrah and Hajj journey. Web app wrapped with Capacitor.

## Get the APK (no Android tools needed on your computer)
1. Create a free GitHub account and a new empty repository.
2. Upload every file and folder from this project (keep `.github/workflows/android.yml`).
3. Open the repository's **Actions** tab, choose **Build Rihla APK**, press **Run workflow**.
4. After about 5 minutes open the finished run and download **Rihla-APK** (contains `app-debug.apk`).
5. Copy the APK to your Android phone, open it, and allow "Install unknown apps" when asked.

## Build on your own computer instead
Needs Node 20, Java 17 and Android Studio (for the SDK).
```
npm install
cp node_modules/three/build/three.min.js www/three.min.js
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
```
The APK is at `android/app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- This is a debug APK for testing and sideloading. A Google Play release needs a signed release build.
- The Arabic fonts load from Google Fonts when online, with system fonts as a fallback offline.
- Progress is stored on the phone only.
- All duas, rulings and translations are drafts and need review by a qualified scholar and translator before public release.
